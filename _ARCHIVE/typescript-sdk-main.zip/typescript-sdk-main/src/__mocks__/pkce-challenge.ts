export default function pkceChallenge() {
    return {
        code_verifier: 'test_verifier',
        code_challenge: 'test_challenge'
    };
}
